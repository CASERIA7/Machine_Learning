from tensorboard.backend.event_processing import event_accumulator

# 加载事件文件
ea = event_accumulator.EventAccumulator("/data1/zkh/universal-ir/tb_logger_lol/events.out.tfevents.1750584225.RTX8000Server1.1942281.0")
ea.Reload()

# 打印所有可以读取的 scalar 标签
print(ea.Tags()["scalars"])  # 比如 ['loss', 'psnr', 'accuracy', ...]

# 读取某个指标，比如 loss
loss_events = ea.Scalars("loss")
for event in loss_events:
    print(f"Step: {event.step}, Loss: {event.value}")
